from collections import Counter
from statistics import mode


class tab_stati_zatrat:
    def Add():
        print('Введите данные через пробел')
        a = input()
        s = '\n' + a
        f.write(s)

    def Edit():
        print('введите индекс строки которую хотите редактировать')
        z = int(input())
        print('апишите данные, которыми хотите заменить существующие')
        a = input() + '\n'
        data = 0
        with open("tab1.txt", "r") as f:
            data = f.readlines()
        with open("tab1.txt", "w") as f:
            for line in data:
                if line.strip("\n") != data[z - 1].strip("\n"):
                    f.write(line)
                else:
                    f.write(a)

    def Remove():
        print("Введите индекс строки которую хотите удалить")
        z = int(input())
        data = 0
        with open("tab1.txt", "r") as f:
            data = f.readlines()
        with open("tab1.txt", "w") as f:
            for line in data:
                if line.strip("\n") != data[z - 1].strip("\n"):
                    f.write(line)


class tad_izdelia:
    def output():
        print("код изделия| название")
        f = open("tab2.txt", "r+")
        print(*f)
        f.close()


class tab_kalkulasia:
    def output():
        print("код калькцляции| код изделия| код статьи| сумма")
        f = open("tab3.txt", "r+")
        print(*f)
        f.close


class tab_plan_vipuska:
    def output():
        print("код плана| код изделия| колличество")
        f = open("tab4.txt", "r+")
        print(*f)
        f.close


while True:
    print("Выберите таблицу \nСтатьи затрат - 1 \nИзделия - 2 \nКалькуляции - 3 \nПлан выпуска - 4 "
          "\nСуммарная себестоимость выпуска изделий на план - 5 \nДоля каждой статьи затрат в общей себестоимости выпуска - 6 "
          "\nВыход - 7")

    tab = int(input())

    if tab == 1:
        while True:
            print("код статьи| название")
            f = open("tab1.txt", "r+")
            print(*f)
            print("Добавить - 1 Редактировать - 2 Удалить - 3 выйти - 4")
            variant = int(input())
            if variant == 1:
                tab_stati_zatrat.Add()
            elif variant == 2:
                tab_stati_zatrat.Edit()
            elif variant == 3:
                tab_stati_zatrat.Remove()
            elif variant == 4:
                break

    elif tab == 2:
        tad_izdelia.output()

    elif tab == 3:
        tab_kalkulasia.output()

    elif tab == 4:
        tab_plan_vipuska.output()

    elif tab == 5:
        with open("tab4.txt") as f:
            data1 = f.readlines()
        with open("tab3.txt") as f:
            data2 = f.readlines()
        summ = []
        koll = []
        x = []
        y = []
        a = 0
        for i in data1:
            koll.append(i.split(" "))
        for i in data2:
            summ.append(i.split(" "))
        for i in summ:
            x.append(int(i[3]))
        for i in koll:
            y.append(int(i[2]))
        for i, j in zip(x, y):
            a = a + (i * j)
        print("Суммарная себестоимость выпуска изделий на план =", a)

    elif tab == 6:
        with open("tab4.txt") as f:
            data1 = f.readlines()
        with open("tab3.txt") as f:
            data2 = f.readlines()
        summ = []
        koll = []
        x = []
        y = []
        a = 0
        v = 0
        for i in data1:
            koll.append(i.split(" "))
        for i in data2:
            summ.append(i.split(" "))
        for i in summ:
            x.append(int(i[3]))
        for i in koll:
            y.append(int(i[2]))
        for i, j in zip(x, y):
            a = a + (i * j)
        print("Доля каждой статьи затрат в общей себестоимости выпуска:")
        for i, j in zip(x, y):
            print(round((i * j) / a * 100))

    elif tab == 7:
        break

